from BS.R import Reader
from S.Club.MyAlliance import MyAlliance
from S.Login.LoginOk import LoginOk
from S.Home.OwnHomeData import OwnHomeData
from S.Home.MapMakerMaps import MapMakerMaps
from DB.DB import DB

import string 
import random
class Login(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.HighID = self.readInt()
        self.LowID = self.readInt()
        self.Token = self.readString()
        self.Major = self.readInt()
        self.Minor = self.readInt()
        self.Build = self.readInt()
        self.Sha = self.readString()
        self.Device = self.readString()
        self.readDataReference()
        self.Lang = self.readString()

    def process(self):
            db = DB()
            	#lettersAndDigits = string.ascii_letters + string.digits
            	#self.player.LowID = int(''.join([str(random.randint(0, 9)) for _ in range(8)]))
            	#self.player.Token = ''.join(random.choice(lettersAndDigits) for i in range(40))
         
            
            
            lettersAndDigits = string.ascii_letters + string.digits
            user = db.loadAccount(self.player, self.Token)
            if user:
            		print("[DB] Loading account...")
            		LoginOk(self.client, self.player).send()
            		OwnHomeData(self.client, self.player).send()
            		MapMakerMaps(self.client, self.player).send()
            		self.player.lastAskedID = self.player.ID
            		if user["aID"] != 0:
            			
            			MyAlliance(self.client, self.player).send()
            		
            else:
            		print("[DB] Creating new account...")
            		
            		
            		if self.LowID == 0:
            			self.player.ID = int(''.join([str(random.randint(0, 9)) for _ in range(8)]))
            			self.player.Token = ''.join(random.choice(lettersAndDigits) for i in range(40))
            			db.createAccount(self.player.ID, self.player.Token, self.player.newData(self.player.ID, self.player.Token))
            		else:
            			
            			db.createAccount(self.LowID, self.Token, self.player.newData(self.LowID, self.Token))
            			self.player.ID = self.LowID
            			self.player.Token = self.Token
            			
            		LoginOk(self.client, self.player).send()
            		OwnHomeData(self.client, self.player).send()
            		MapMakerMaps(self.client, self.player).send()
            			
            print(f"[LOG IN] {self.HighID}, {self.LowID}, {self.Token} | v{self.Major}.{self.Build} | {self.Sha} | {self.Device} | {self.Lang}")
           # MyAllianceMessage(self.client, self.player).send()
            #AllianceDataMessage(self.client, self.player).send()
           # sleep(5)
            #LobbyInfoMessage(self.client, self.player).send()