from BS.R import Reader
from S.Room.Team import Team

class SetReadyTeam(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
      #  self.invites = []
        self.isReady = self.readBool()

    def process(self):
        self.player.isReady = self.isReady
        Team(self.client, self.player).send()