from BS.R import Reader
from S.Room.Team import Team
from S.Room.TeamError import TeamError

class TeamSpectate(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.wddd = {}
        self.wddd["hid"] = self.readVInt()
        self.wddd["lid"] = self.readVInt()
        self.wddd["c"] = self.readVInt()

    def process(self):
        if self.player.inTeam == False:
        	print(f"inf: {self.wddd}")
        	self.player.roomType = 0
        	self.player.roomID = self.wddd["lid"]
        	self.player.isReady = False
        	self.player.inTeam = True
        	Team(self.client, self.player).send()
        	
        else:
        	TeamError(self.client, self.player).send()
        	