from BS.R import Reader
from S.Room.Team import Team
import random
class CreateTeam(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.mapSlot = self.readVInt()
        self.mapID = self.readVInt()
        self.roomType = self.readVInt()

    def process(self):
        print(f"Slot: {self.mapSlot}, ID: {self.mapID}, Type: {self.roomType}")
        self.player.roomType = self.roomType
        self.player.isReady = False
        self.player.roomID = random.randint(1, 9999999)
        self.player.inTeam = True
        
        Team(self.client, self.player).send()