from BS.R import Reader
#from Packets.Messages.Server.Battle.BattleEndMessage import BattleEndMessage
from S.Room.Team import Team
import time

class SetLocationTeam(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.readVInt()
        self.none = self.readVInt()

    def process(self):
       self.player.mapID = self.none
       Team(self.client, self.player).send()
       #LobbyInfoMessage(self.client, self.player).send()
      # BattleEndMessage(self.client, self.player).send()