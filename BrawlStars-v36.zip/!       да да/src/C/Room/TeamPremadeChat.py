from BS.R import Reader

from S.Room.TeamStream import TeamStream

class TeamPremadeChat(Reader):
	#14369
	def __init__(self, client, player, initial_bytes):
		super().__init__(initial_bytes)
		self.client = client
		self.player = player
	def decode(self):
		self.info = {}
		self.info["a"] = self.readScId()
		self.info["b"] = self.readBoolean()
		self.info["c"] = self.readLong()
		self.info["d"] = self.readVInt()
		self.info["e"]= self.readVInt()
		self.info["f"] = self.readVInt()
		 
	def process(self):
		print(self.info)
		self.player.pin = self.info["a"][1]
		self.player.ctick += 1
		TeamStream(self.client, self.player).send()