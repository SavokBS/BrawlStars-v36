from BS.R import Reader
from S.Room.TeamLeft import TeamLeft

class LeaveTeam(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
        self.player.inTeam = False
        TeamLeft(self.client, self.player).send()