from BS.R import Reader
from Day import Day

from S.Home.Leaderboard import Leaderboard

from S.Home.BrawlerLeaderboard import BrawlerLeaderboard
from DB.DB import DB

class GetLeaderboard(Reader):
	#14403
	def __init__(self, client, player, initial_bytes):
		super().__init__(initial_bytes)
		self.client = client
		self.player = player
	def decode(self):
		self.local = self.readBool()
		self.type = self.readVInt()
		self.dudka = self.readDataReference()[0]
		self.brawler = self.readDataReference()[1]
		
	def process(self):
		print(f"[LB] Type: {self.type}, Local: {self.local}, {self.dudka}\n{self.brawler}")
		#ay(self.client, self.player).send(
		Leaderboard(self.client, self.player).send()
			