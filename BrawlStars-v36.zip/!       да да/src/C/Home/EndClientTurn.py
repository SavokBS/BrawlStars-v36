from BS.R import Reader
from Logic.PacketsHelper import PacketsHelper as ph
from DB.DB import DB
from S.Room.Team import Team
from Box import Box
class EndClientTurn(Reader):
	def __init__(self, client, player, initial_bytes):
		super().__init__(initial_bytes)
		self.player = player
		self.client = client
		
	def decode(self):
		self.readVInt()
		self.readVInt()
		self.readVInt()
		self.tickCheck = self.readVInt()
		self.commandID = self.readVInt()
		
	def process(self):
		db = DB()
		user = db.loadPlayer(self.player.ID)
		name = ph.getCommandName(self.commandID)
		if self.commandID >= 0:
			print(f"[COMMAND] ID: {self.commandID}, Name: {name}, Tick: {self.tickCheck}")
		if self.commandID == 505:
		    self.readVInt()
		    self.readVInt()
		    self.readVInt()
		    self.readVInt()
		    self.readVInt()
		    self.player.icon = self.readVInt()
		    user["icon"] = self.player.icon
		    db.replaceValue(user, self.player.Token)
		    
		elif self.commandID == 527:
		    for i in range(5):
		      	self.readVInt()
		    self.player.cname = self.readVInt()
		    user["cname"] = self.player.cname
		    db.replaceValue(user, self.player.Token)
		    
		elif self.commandID == 506:
		    for i in range(5):
		      	self.readVInt()
		    self.player.skin = self.readVInt()
		    for i in range(6):
		      	self.readVInt()
		    self.player.brawler = self.readVInt()
		    user["skin"] = self.player.skin
		    user["brawler"] = self.player.brawler
		    db.replaceValue(user, self.player.Token)
		    if self.player.inTeam == True:
		      	Team(self.client, self.player).send()
		elif self.commandID == 500 or self.commandID == 517:
		      	Box(self.client, self.player).send()
        	#db.replaceValueInt("cname", self.player.cname, self.player.Token)