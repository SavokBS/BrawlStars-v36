from BS.R import Reader

from S.Home.PlayerProfile import PlayerProfile

class GetPlayerProfile(Reader):
	#14113
	def __init__(self, client, player, initial_bytes):
		super().__init__(initial_bytes)
		self.client = client
		self.player = player
	def decode(self):
		self.readInt()
		self.ID = self.readInt()
		
	def process(self):
		self.player.lastAskedID = self.ID
		print(f"OMG??? {self.player.lastAskedID}")
		PlayerProfile(self.client, self.player, self.ID).send()