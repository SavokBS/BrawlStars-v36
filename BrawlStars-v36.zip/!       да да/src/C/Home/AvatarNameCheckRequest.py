from BS.R import Reader
from S.Home.AvatarNameCheckResponce import AvatarNameCheckResponce
from DB.DB import DB 

class AvatarNameCheckRequest(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.newName = self.readString()
        

    def process(self):
        db = DB()
        user = db.loadPlayer(self.player.ID)
        self.player.name = self.newName
        user["name"] = self.newName
        db.replaceValue(user, self.player.Token)
        AvatarNameCheckResponce(self.client, self.player).send()