from BS.R import Reader
from S.Battle.BattleEnd import BattleEnd
#from Packets.Messages.Server.Lobby.LobbyInfoMessage import LobbyInfoMessage
import time
from Day import Day
from datetime import datetime

class KeepAlive(Reader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
       #BattleEnd(self.client, self.player).send()
       
       pass