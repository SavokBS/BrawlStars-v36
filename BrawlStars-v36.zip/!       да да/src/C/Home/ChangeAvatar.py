from BS.R import Reader
from DB.DB import DB
from S.Home.AvatarResponce import AvatarResponce
class ChangeAvatar(Reader):
	def __init__(self, client, player, initial_bytes):
		super().__init__(initial_bytes)
		self.client = client
		self.player = player
	def decode(self):
		self.Name = self.readString()
		
	def process(self):
		db = DB()
		user = db.loadPlayer(self.player.ID)
		self.player.name = self.Name
		user["name"] = self.Name
		user["nameSet"] = 1
		db.replaceValue(user, self.player.Token)
		self.player.nameSet = 1
		AvatarResponce(self.client, self.player).send()
		