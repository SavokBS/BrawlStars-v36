import string
import random
class Player:
	ID = 0
	Token = ""
	name = "Tara's clone"
	nameSet = 0
	trophies = 0
	xp = 0
	gottenxp = 0
	icon = 0
	cname = 0
	brawler = 0
	skin = 0
	cat = False
	v3 = 0
	bet = 0
	mapID = 7
	ctick = 0
	pin = 0
	inTeam = False
	
	
	isInClub = False
	aID = 0
	aname = ""
	adesc = ""
	aicon = 0
	atype = 0
	atrop = 0
	aff = 0
	
	
	brtrop = {"0": 0, "1": 0, "2": 0, "3": 0, "4": 0, "5": 0, "6": 0, "7": 0, "8": 0, "9": 0, "10": 0, "11": 0, "12": 0, "13": 0, "14": 0, "15": 0, "16": 0, "17": 0, "18": 0, "19": 0, "20": 0, "21": 0, "22": 0, "23": 0, "24": 0, "25": 0, "26": 0, "27": 0, "28": 0, "29": 0, "30": 0, "31": 0, "32": 0, "34": 0, "35": 0, "36": 0, "37": 0, "38": 0, "39": 0, "40": 0, "41": 0, "42": 0, "43": 0, "44": 0, "45": 0, "46": 0, "47": 0, "49": 0, "50": 0}

	def __init__(self):
		pass
		
	def newData(self, id, token):
		self.ID = id
		self.Token = token
		
		Data = {
		"ID": self.ID, 
		"Token": self.Token, 
		"name": self.name, 
		"nameSet": self.nameSet, 
		"trophies": self.trophies,
		"xp": self.xp,
		"icon": self.icon, 
		"cname": self.cname, 
		"brawler": self.brawler, 
		"skin": self.skin, 
		"v3": self.v3,
		"brtrop": self.brtrop, 
		"isInClub": self.isInClub,
		"aID": self.aID,
		"aname": self.aname,
		"adesc": self.adesc,
		"aicon": self.aicon,
		"atype": self.atype,
		"atrop": self.atrop,
		"aff": self.aff
		}
		return Data
		
	