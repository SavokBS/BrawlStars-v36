from Logic.CSV.R import CsvReader
class Cards:
    def get_brawler_unlock():
        CardUnlockID = []
        reader = CsvReader()
        rowData = reader.readCsv('Logic/CSV/Files/cards.csv')
        for row in rowData:
            if row[7].lower() == '0':
                CardUnlockID.append(rowData.index(row))
        return CardUnlockID