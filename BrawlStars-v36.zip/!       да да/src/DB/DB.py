import sqlite3
import json
import traceback

reason = traceback.format_exc()

class DB():
	def __init__(self):
		self.conn = sqlite3.connect("DB/db.sqlite")
		self.cursor = self.conn.cursor()
		try:
			self.cursor.execute("CREATE TABLE main (ID int, Token text, Data json)")
		except:
			pass
			
	def createAccount(self, id, token, data):
		try:
			self.cursor.execute("INSERT INTO main (ID, Token, Data) VALUES (?, ?, ?)", (id, token, json.dumps(data, ensure_ascii=0)))
			self.conn.commit()
		except Exception:
			print(traceback.format_exc())
			
	def loadAccount(self, player, token):
		try:
			self.cursor.execute(f"SELECT * FROM main WHERE Token = '{token}'")
			this = json.loads(self.cursor.fetchall()[0][2])
			player.ID = this["ID"]
			player.Token = this["Token"]
			player.name = this["name"]
			player.nameSet = this["nameSet"]
			player.trophies = this["trophies"]
			player.xp = this["xp"]
			player.icon = this["icon"]
			player.cname = this["cname"]
			player.brawler = this["brawler"]
			player.skin = this["skin"]
			player.v3 = this["v3"]
			player.brtrop = this["brtrop"]
			player.isInClub = this["isInClub"]
			player.aID = this["aID"]
			player.aname = this["aname"]
			player.adesc = this["adesc"]
			player.aicon = this["aicon"]
			player.atype = this["atype"]
			player.atrop = this["atrop"]
			player.aff = this["aff"]
			return this
		except Exception:
			print(traceback.format_exc())
	
	def loadPlayer(self, id):
			try:
				self.cursor.execute(f"SELECT * FROM main WHERE ID = {id}")
				this = json.loads(self.cursor.fetchall()[0][2])
				return this
			except Exception:
				print(traceback.format_exc())
	
	def loadAll(self):
			a = []
			self.cursor.execute("SELECT * FROM main")
			this = self.cursor.fetchall()
			for db in this:
				data = json.loads(db[2])
				a.append(data)
			return a
				
			
			
	def replaceValue(self, data, token):
			try:
				self.cursor.execute(f"UPDATE main SET Data=? WHERE Token=?", (json.dumps(data, ensure_ascii=0), token))
				self.conn.commit()
			except Exception:
				print(traceback.format_exc())
				
	def sortPlayers(self, value):
			result = self.loadAll()
			sorter = sorted(result, key=lambda x:x[value], reverse=True)
			return sorter
			
			