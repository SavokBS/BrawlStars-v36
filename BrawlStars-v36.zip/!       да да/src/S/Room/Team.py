from BS.W import Writer
import random


class Team(Writer):
    def __init__(self, client, player, invites=0):
        super().__init__(client)
        self.player = player
        self.id = 24124
        self.invites = invites

    def encode(self):
        #db = DBSQL()
        self.writeVInt(self.player.roomType)
        self.writeBoolean(False)
        self.writeVInt(1)
        
        self.writeInt(0)
        self.writeInt(self.player.roomID)
        
        self.writeVInt(0)
        
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeDataReference(15, self.player.mapID)
        self.writeBoolean(False)
        
        if self.invites >= 1:
        	self.writeVInt(2)
        else:
        	self.writeVInt(1)

        #PlayerEntry
        self.writeBoolean(True) #Owner
        self.writeLong2(0, self.player.ID) 
        self.writeDataReference(16, self.player.brawler)
        self.writeDataReference(29, self.player.skin)
        
        self.writeVInt(self.player.brtrop[f"{self.player.brawler}"]) #t
        self.writeVInt(self.player.brtrop[f"{self.player.brawler}"]) #ht
        self.writeVInt(9)
        self.writeVInt(3) #State                               
        
        self.writeBoolean(self.player.isReady) # Is ready
        self.writeVInt(0) #Team
        self.writeVInt(52000000 + 69)
        self.writeVInt(52000000 + 69)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeString(self.player.name) #name
        self.writeVInt(100)
        self.writeVInt(28000000 + self.player.icon)  #  icon
        self.writeVInt(43000000 + self.player.cname)    # name color
        self.writeVInt(-1)
        self.writeVInt(0) #sp
        self.writeVInt(0)   #jaja 
        self.writeVInt(self.player.pin)
        
        
    
        
        #aja 

#        self.writeVInt(0)

#    

#        

#        self.writeBoolean(False) #Owner

#        self.writeLong2(0, 2)

#        self.writeDataReference(16, self.player.selbrwlr)

#        self.writeDataReference(29, self.player.selskin + 1)

#        

#        self.writeVInt(1250)

#        self.writeVInt(1250)

#        self.writeVInt(9)

#        self.writeVInt(3) #State      

#        

#        self.writeBoolean(False) # Is ready

#        self.writeVInt(0) #Team

#        self.writeVInt(0)

#        self.writeVInt(0)

#        self.writeVInt(0)

#        self.writeVInt(0)

#        

#        self.writeString("t.me/vokesbrawl") #name

#        self.writeVInt(100)

#        self.writeVInt(28000000)  #  icon

#        self.writeVInt(43000000)    # name color

#        self.writeVInt(-1)

#        sel
        
        
        if self.invites != 0:
        	self.writeVInt(0)
        #	self.writeVInt(self.invites)
        #	for i in range(self.invites):
        		#self.writeLong2(0, i)
        		#self.writeLong2(0, 1)
        	#	self.writeString("Приглашенный")
        	#	self.writeVInt(0)
        else:
        	self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(6)