from BS.W import Writer
from S.Room.Team import Team
import random

class TeamStream(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 24131

    def encode(self):
        fm = []
        self.writeVInt(0)
        self.writeVInt(self.player.roomID)
        self.writeVInt(1)
        for i in range(1):
                if self.player.pin in fm:
                	self.writeVint(6)
                else:
                	self.writeVInt(8)
                # StreamEntry::encode
                self.writeVInt(0)
                self.writeVInt(self.player.ctick) # tick
                self.writeVInt(0)
                self.writeVInt(self.player.ID)
                self.writeString(self.player.name)
                self.writeVint(0)
                self.writeVint(0) # Age Seconds (TID_STREAM_ENTRY_AGE)
                self.writeVint(0) # Boolean
                if self.player.pin in fm:
                	self.writeScId(40, 0)
                else:
                	self.writeDataReference(40, self.player.pin) # Message Data ID (40 - messages.csv)
                	self.writeBoolean(True) # Target Boolean
                	self.writeString(self.player.name) # Target Name
                	self.writeVint(0) # ??
                	self.writeVint(52000000 + self.player.pin) # ScID (eg. 52000319 [trixie colette thanks pin] if message data id is (40, 46) and event 8)
        Team(self.client, self.player).send()
                
        