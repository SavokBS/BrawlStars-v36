from BS.W import Writer

class AvatarResponce(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 24111

    def encode(self):
        self.writeVInt(201)
        self.writeString(self.player.name)
        self.writeVInt(99999)