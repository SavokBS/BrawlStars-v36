from BS.W import Writer
from DB.DB import DB

class Leaderboard(Writer):

    def __init__(self, client, player, type=0):
        super().__init__(client)
        self.player = player
        self.id = 24403
        self.type = type

    def encode(self):
        db = DB()
        #data = db.sortPlayers('trophies')
        data = db.sortPlayers('trophies')
        self.writeBoolean(True)
        self.writeVint(0)
        self.writeVint(0)
        self.writeString()

        self.writeVint(len(data)) # Players Count

        for i in range(len(data)):
            self.writeVint(0) # High ID
            self.writeVint(data[i]["ID"]) # Low ID

            self.writeVint(1)
            self.writeVint(data[i]["trophies"]) # Player Trophies

            self.writeVint(1)

            self.writeString()
                
            self.writeString(data[i]["name"]) # Player Name
            self.writeVint(0) # Player Level
            self.writeVint(28000000 + data[i]["icon"])
            self.writeVint(43000000 + data[i]["cname"])
            self.writeVInt(0)
            self.writeVint(0) # Unknown


        self.writeVint(0)
        for i in data:
        	if i["ID"] == self.player.ID:
        		self.writeVInt(data.index(i) + 1)
        self.writeVint(0)
        self.writeVint(0) # Leaderboard global TID
        self.writeString("VokesBrawl")