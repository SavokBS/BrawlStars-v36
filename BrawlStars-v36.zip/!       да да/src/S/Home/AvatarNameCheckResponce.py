from BS.W import Writer

class AvatarNameCheckResponce(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 20300

    def encode(self):
        self.writeVInt(0)
        self.writeInt(1)
        self.writeString(self.player.name)