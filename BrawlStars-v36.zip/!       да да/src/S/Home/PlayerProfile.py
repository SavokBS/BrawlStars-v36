from BS.W import Writer
from DB.DB import DB
import random

class PlayerProfile(Writer):
	def __init__(self, client, player, id):
		super().__init__(client)
		self.player = player
		self.id = 24113
		self.plrid = id
		
	def encode(self):
		db = DB()
		data = db.loadPlayer(self.plrid)
		self.writeVInt(0)
		self.writeVInt(self.plrid)
		self.writeBoolean(False)
		
		self.writeVInt(len(data["brtrop"])) #Brawlers
		
		for i in data["brtrop"]:
				self.writeScId(16, int(i))
				self.writeVInt(0)
				self.writeVInt(data["brtrop"][f"{int(i)}"])
				self.writeVInt(data["brtrop"][f"{int(i)}"])
				self.writeVInt(9)
			
		
		
		self.writeVInt(15)
		
		self.writeVInt(1)
		self.writeVInt(data["v3"]) #3vs3 wins
		
		self.writeVInt(2)
		self.writeVInt(data["xp"]) #X
		
		self.writeVInt(3)
		self.writeVInt(data["trophies"]) #HighestTrophies
		
		self.writeVInt(4)
		self.writeVInt(data["trophies"]) #Trophies
		
		self.writeVInt(5)
		self.writeVInt(len(data["brtrop"])) #Brawlers list
		
		self.writeVInt(7)
		self.writeVInt(28000000 + data["icon"]) #ProfileIcon
		
		self.writeVInt(8)
		self.writeVInt(0) #SoloWins
		
		self.writeVInt(9)
		self.writeVInt(0) #Roborumble LVL
		
		self.writeVInt(11)
		self.writeVInt(0) #DuoWins
		
		
		self.writeVInt(12)
		self.writeVInt(0) #BossFight LVL
		
		self.writeVInt(15)
		self.writeVInt(0) #Most chalenges wins
		
		self.writeVInt(16)
		self.writeVInt(0) #CityFight LVL
		
		
		self.writeVInt(17)
		self.writeVInt(0) #Highest Team League
		
		self.writeVInt(18)
		self.writeVInt(0) #Highest Solo League
		
		self.writeVInt(19)
		self.writeVInt(0) #Highest Club League
		
		self.writeString(data["name"])
		self.writeVInt(0)
		self.writeVInt(28000000 + data["icon"])
		self.writeVInt(43000000 + data["cname"])
		self.writeVInt(0) #Gradients
		
		self.writeBoolean(data["isInClub"])  # Is in club
		
		if data["isInClub"] == True:
			self.writeInt(0)
			self.writeInt(data["aID"]) #Club ID
			
			self.writeString(data["aname"])  # club name
			self.writeVInt(8)
			self.writeVInt(data["aicon"][1])  # Club badgeID
			self.writeVInt(data["atype"])  # club type | 1 = Open, 2 = invite only, 3 = closed
			self.writeVInt(1)  # Current members count
			self.writeVInt(0) #Club Trophies
			self.writeVInt(0)  # Trophy required
			self.writeVInt(0)  # (Unknown)
			self.writeString("RU")  # region
			self.writeVInt(0)  # (Unknown)
			self.writeVInt(0) # (Unknown)
			self.writeVInt(25)
			self.writeVInt(2)
		