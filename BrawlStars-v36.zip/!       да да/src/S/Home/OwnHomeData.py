from BS.W import Writer
from Logic.CSV.Cards import Cards
from datetime import datetime
import time
class OwnHomeData(Writer):
	def __init__(self, client, player):
		super().__init__(client)
		self.player = player
		self.id = 24101
		
	def encode(self):
		time_stamp = int(datetime.timestamp(datetime.now()))
		
		self.writeVInt(time_stamp)
		self.writeVInt(time_stamp)
		
		self.writeVInt(self.player.trophies) #Trophies
		self.writeVInt(self.player.trophies) #Highest Trophies
		self.writeVInt(0)
		
		self.writeVInt(200) #TrophyRoadReward
		self.writeVInt(50000) #Exp
		
		self.writeDataReference(28, self.player.icon) #ProfileIcon
		self.writeDataReference(43, self.player.cname) #NameColor
		
		self.writeVInt(50)
		for x in range(50):
			self.writeVInt(x)
			
		self.writeVInt(1)
		for x in range(1):
			self.writeScId(29, self.player.skin)
			
		self.writeVInt(0)
		for x in range(0):
			self.writeVInt(x)
			
		self.writeVInt(521) #UnlockedSkins
		for i in range(521):
			self.writeScId(29, i)
		
		self.writeVInt(0)
		for x in range(0):
			self.writeVInt(x)
			
			
		self.writeVInt(0) ###
			
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(1)
		self.writeVInt(1)
		
		self.writeUInt8(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		
		self.writeBoolean(False)
		self.writeBoolean(False)
		
		
		self.writeUInt8(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(2)
		self.writeVInt(0)
		self.writeVInt(999999)
		
		self.writeVInt(0)
		for x in range(0):
			self.writeVInt(x)
			
		self.writeVInt(0)
		for x in range(0):
			self.writeVInt(x)
			
		self.writeVInt(0) #array?
		self.writeVInt(0)
		
		self.writeVInt(0)
		for x in range(0):
			self.writeVInt(x)
			
		self.writeVInt(0)
			
		self.writeVInt(0)
		self.writeVInt(1)
		
		self.writeDataReference(16, self.player.brawler) #HomeBrawler
		
		self.writeString("RU") #Region
		self.writeString("SaVok") #ContentCreator
		
		self.writeVint(1) #a dudka
		self.writeInt(4)
		self.writeInt(self.player.bet)
			
		self.writeVInt(0)
		
		self.writeVInt(2)
		for i in [5, 6]:
			self.writeVInt(i)
			self.writeVInt(0)
			self.writeBool(False)
			self.writeVInt(30)
			
			self.writeByte(2)
			for i in range(4):
				self.writeInt(0)
				
			self.writeByte(1)
			for i in range(4):
				self.writeInt(0)
			
		
		self.writeVInt(0)
		
		self.writeBoolean(True)
		self.writeVInt(0)
		
		self.writeBoolean(True)
		self.writeVInt(523)
		for i in range(523):
			self.writeScId(52, i)
			self.writeVInt(1)
			self.writeVInt(1)
			self.writeVInt(1)
	
		self.writeBoolean(False)
		
		self.writeInt(0)
		
		#ConfData
		
		self.writeVInt(0)
		
		self.writeVInt(20)
		for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 20, 21, 22, 23, 24]:
			self.writeVInt(x)
			
		self.writeVInt(9) #EventsCount
		index = 0
		
		for i in [9, 10, 54, 82, 115, 404, 295, 379, 370]:
		    self.writeVInt(0)
		    if i != 379:
		    	self.writeVInt(index) #Index
		    else:
		    	self.writeVInt(10)
		    self.writeVInt(0) #Ended
		    self.writeVInt(0) #Timer
		    self.writeVInt(0)
		    self.writeDataReference(15,  i)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeString()
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeBoolean(False) #Modifiers
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    self.writeVInt(0)
		    index += 1
		
		#self.writeVInt(-1)
#		self.writeVInt(13) #Index
#		self.writeVInt(0) #Ended
#		self.writeVInt(60 - datetime.now().second) #Timer
#		self.writeVInt(0)
#		self.writeDataReference(15, 7)
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeString("zh")
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeBoolean(False) #Modifiers
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeBool(False)
#		self.writeVInt(0)
#		self.writeVInt(0)
#		self.writeVInt(0)
		
		self.writeVInt(0)
			
			
		self.writeVInt(0)
		self.writeArrayVint([20, 50, 140, 280])
		self.writeArrayVint([150, 400, 1200, 2600])
		
		self.writeUInt8(1)
		
		self.writeVInt(0)
		for x in range(0):
			self.writeVInt(x)
			
			
		self.writeVInt(1)
		for x in range(1):
		    self.writeInt(1)
		    self.writeInt(41000000 + 27)
		    
		self.writeVInt(0)
		for x in range(0):
			self.writeVInt(x)
			
		self.writeVInt(0)
		for x in range(0):
			self.writeVInt(x)
			
		self.writeLong(self.player.ID)
		
		if self.player.cat == True:
			self.writeVInt(0)
		else:
			self.writeVInt(1) # NotificationFactory
			self.writeVInt(83) # чо
			self.writeInt(0)
			self.writeBoolean(False)
			self.writeInt(0)
			self.writeString("SaVok")
			self.writeInt(0)
			self.writeString("Добро пожаловать в Vokes Brawl!")
			self.writeInt(0)
			self.writeString("Поддержи наш проект и зайди в телеграм")
			self.writeInt(0)
			self.writeString("ТЕЛЕГРАМ")
			self.writeString("/b2d704b22b95a4d70f66e89da867a64b")
			self.writeString('3a35620676c1d08d12086257a5ae03eb612452d8')
			self.writeString("brawlstars://extlink?page=https%3A%2F%2Ft.me%2Fvokesbrawl")
			self.writeVInt(3473)
		
		self.writeVInt(0)
		
		self.writeUInt8(0)
		
		self.writeVInt(0)
		
		self.writeVInt(0)
		for x in range(0):
		      self.writeVInt(x)
		      
		      
		      
		for x in range(3):
			self.writeLogicLong(self.player.ID)
			
		self.writeString(f"{self.player.name}")
		self.writeVInt(self.player.nameSet)
		self.writeInt(0)
		
		self.writeVInt(8) #Commodities Count
		cards = Cards.get_brawler_unlock()
		self.writeVInt(3 + 50)
		
		for i in cards:
		    self.writeDataReference(23, i)
		    self.writeVInt(1)
		    
		self.writeDataReference(5, 8) #Coins
		self.writeVInt(100)
		
		self.writeDataReference(5, 10) #Starpoints
		self.writeVInt(0)
		#print(self.player.brtrop["2"])
		
		
		self.writeVInt(len(self.player.brtrop)) #Trophies
		for x in self.player.brtrop:
		    self.writeDataReference(16, int(x))
		    self.writeVInt(self.player.brtrop[f"{int(x)}"])

		    
		self.writeVInt(len(self.player.brtrop)) #Trophies
		for x in self.player.brtrop:
		    self.writeDataReference(16, int(x))
		    self.writeVInt(self.player.brtrop[f"{int(x)}"])
		    
		
		self.writeVInt(0) #spgd
		
		
		self.writeVInt(51) #Power Points
		for x in range(51):
		    self.writeDataReference(16, x)
		    self.writeVInt(1410)
		    
		self.writeVInt(51) #LVL
		for x in range(51):
		    self.writeDataReference(16, x)
		    self.writeVInt(8)
		    
		    
		self.writeVInt(0)
		for x in range(0):
		    self.writeDataReference(23, 0)
		    self.writeVInt(1)
		    
		    
		self.writeVInt(0)
		for x in range(0):
		    self.writeDataReference(16, x)
		    self.writeVInt(0)
		    
		self.writeVInt(999999) #Fre Gems
		self.writeVInt(0) #Gems
		
		
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		self.writeVInt(0)
		
		self.writeVInt(2)
		self.writeVInt(time_stamp)
		
		self.player.cat = True