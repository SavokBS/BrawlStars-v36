from BS.W import Writer
from DB.DB import DB
import random

class BattleEnd(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 23456

    def encode(self):
        self.writeLong2(0, 1) # ByteStream::writeLongLong
        self.writeLong2(0, 1) # ByteStream::writeLongLong
        self.writeVInt(1) # Battle End Game Mode
        self.writeVInt(0) # Result (Victory/Defeat/Draw/Rank Score)
        self.writeVInt(0) # Tokens Gained
        self.writeVInt(self.player.bet) # Trophies Result
        self.writeVInt(0) # Power Play Points Gained
        self.writeVInt(0) # Doubled Tokens
        self.writeVInt(0) # Double Token Event
        self.writeVInt(0) # Token Doubler Remaining
        self.writeVInt(0) # Special Events Level Passed
        self.writeVInt(0) # Epic Win Power Play Points Gained
        self.writeVInt(0) # Championship Level Reached
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(16) #Type
        self.writeVInt(-1)
        self.writeBoolean(False)

        self.writeVInt(2)  # Players

        # PlayerEntry::encode
        self.writeByte(1)
        self.writeDataReference(16, self.player.brawler)  # BrawlerID
        self.writeDataReference(29, self.player.skin)  # SkinID
        self.writeVInt(self.player.brtrop[f"{self.player.brawler}"] - self.player.bet) # Trophies
        self.writeVInt(1)
        self.writeVInt(9) # PowerLevel
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeLong2(0, self.player.ID)

        self.writeString(self.player.name)  # PlayerName
        self.writeVInt(200)
        self.writeVInt(28000000)  # PlayerThumbnail
        self.writeVInt(43000000 + self.player.cname)  # NameColor
        self.writeVInt(-1)
        
        
        
        
        self.writeByte(10)
        self.writeDataReference(16, 49)  # BrawlerID
        self.writeDataReference(29, 0)  # SkinID
        self.writeVInt(self.player.trophies - self.player.bet + random.randint(10, 50)) # Trophies
        self.writeVInt(1)
        self.writeVInt(9) # PowerLevel
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeLong2(0, 2)

        self.writeString("SaVoK")  # PlayerName
        self.writeVInt(100)
        self.writeVInt(28000000)  # PlayerThumbnail
        self.writeVInt(43000001 + self.player.cname)  # NameColor
        self.writeVInt(-1)
       

        # PlayerEntry::encode End

        self.writeVInt(1)  # XpEntry
        self.writeVInt(0) #ID
        self.writeVInt(self.player.gottenxp) #Gotten Xp

        self.writeVInt(0)

        self.writeVInt(2)  # LogicMilestoneProgress
        self.writeVInt(1)
        self.writeVInt(self.player.brtrop[f"{self.player.brawler}"] - self.player.bet)
        self.writeVInt(self.player.brtrop[f"{self.player.brawler}"] - self.player.bet)
        self.writeVInt(5)
        self.writeVInt(self.player.xp - self.player.gottenxp)
        self.writeVInt(0)

        self.writeDataReference(28, 0)

        self.writeBoolean(False)  # PlayAgainStatus

        self.writeBoolean(False)  # LogicQuests

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # LogicRankedMatchRoundState
        self.writeVInt(-1)
        self.writeBoolean(False)  # ChronosTextEntry
        
        #self.player.gottrop = self.player.bet