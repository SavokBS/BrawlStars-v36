from BS.W import Writer
import random
from DB.DB import DB

class AllianceData(Writer):
    def __init__(self, client, player):
        super().__init__(client)
        self.player = player
        self.id = 24301

    def encode(self):
        db = DB()
        user = db.loadPlayer(self.player.lastAskedID)
        self.writeBoolean(False)
        self.writeLong2(0, self.player.neededClub) #hlid
        self.writeString(user["aname"]) #name
        self.writeDataReference(8, user["aicon"][1]) #badge
        self.writeVInt(user["atype"]) # Type
        self.writeVInt(1)  # Total Members
        self.writeVInt(user["trophies"])  # Total Trophies
        self.writeVInt(user["atrop"])  # Trophies Required
        self.writeDataReference(0)
        self.writeString("RU")  # Region
        self.writeVInt(0)
        self.writeBoolean(user["aff"])  # Family Friendly

        self.writeString(user["adesc"]) # Description
        #online = self.player.ClientDict["Clients"]
        self.writeVInt(1) # Members Count
        
        self.writeLong2(0, user["ID"])
        self.writeVInt(2)
        self.writeVInt(user["trophies"]) # Trophies
        self.writeVInt(2)
        self.writeVInt(6974) # State Timer
        self.writeVInt(0)
        self.writeBoolean(False) #DND
        self.writeString(user["name"])
        self.writeVInt(100)
        self.writeVInt(28000000 + user["icon"]) # Player Thumbnail
        self.writeVInt(43000000 + user["cname"]) # Player Name Color
        self.writeVInt(42000000) # Color Gradients

        self.writeVInt(0)
        
        