from BS.W import Writer
from random import randint as r

class Box(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24111
        self.player = player

    def encode(self):
    	#def get_id(id):
#            if id == 5:  # Brawl Box         
#                return 10
#            elif id == 4:  # Big Box
#                self.box_index = 1
#                return 12
#            elif id == 3:  # Shop Mega Bo
#                return 11
#            elif id == 1:  # Shop Big Bo
#                return 12
#            elif id == 6:  # Trophy Road Brawl Box
#                return 10
#            elif id == 7:  # Trophy Road Brawl Box
#                return 12
#            elif id == 8:  # Trophy Road Brawl Box
#                return 11
#            elif id == 9:  # Brawl Pass Brawl Box
#                return 10
#            elif id == 10:  # Brawl Pass Big Box
#                return 12
    #	box = get_id(self.player.box)
    	#print(f"BOX: {box}")
    	self.writeVInt(203)
    	self.writeVInt(0)
    	self.writeVInt(1)
    	self.writeVInt(11)
    	
    	self.writeVInt(2)
    		
    	
    	self.writeVInt(r(100, 500))
    	self.writeScId(16, 0)
    	self.writeVInt(7)
    	self.writeVInt(0) #29
    	self.writeVInt(0) #52
    	self.writeVInt(0) #23
    	self.writeVInt(0)
    	self.writeVInt(0)
    	
    	self.writeVInt(r(100, 500))
    	self.writeScId(16, r(0, 50))
    	self.writeVInt(1)
    	self.writeVInt(0) #29
    	self.writeVInt(0) #52
    	self.writeVInt(0) #23
    	self.writeVInt(0)
    	self.writeVInt(0)
    	
    	
    	
    	self.writeBoolean(False)
    	self.writeVInt(0)
    	self.writeLogicLong(-1)
    	