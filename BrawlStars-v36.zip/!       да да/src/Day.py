from BS.W import Writer
import random

class Day(Writer):
 def __init__(self, client, player):
 	super().__init__(client)
 	self.player = player
 	self.id = 24111
 def encode(self):
     self.writeVInt(204)
    # self.writeVint(0)
    # self.writeVint(0)
    # self.writeVInt(0)
     
     self.writeVInt(1)
     
     self.writeVInt(0)
     
     self.writeVInt(20)
     for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 20, 21, 22, 23, 24]:
     	self.writeVInt(x)
     gg = [9, 10, 115]
     h = [54, 82, 404]
     
     map1 = random.choice(gg)
     map2 = random.choice(h)
     
     self.player.map1 = map1
     self.player.map2 = map2
     	
     self.writeVInt(2) #EventsCount
     
     self.writeVInt(0)
     self.writeVInt(1) #Index
     self.writeVInt(0) #Ended
     self.writeVInt(60) #Timer
     self.writeVInt(0)
     self.writeDataReference(15, map1)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeString()
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeBoolean(False) #Modifiers
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     
     self.writeVInt(0)
     self.writeVInt(2) #Index
     self.writeVInt(0) #Ended
     self.writeVInt(60) #Timer
     self.writeVInt(0)
     self.writeDataReference(15, map2)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeString()
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeBoolean(False) #Modifiers
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     self.writeVInt(0)
     
     self.writeVInt(0) #NewEvent
     for x in range(0):
     	self.writeVInt(x)
     	
     	
     self.writeVInt(0)
     self.writeArrayVint([20, 50, 140, 280])
     self.writeArrayVint([150, 400, 1200, 2600])
     
     self.writeUInt8(1)
     
     self.writeVInt(0) #ReleaseEntry
     for x in range(0):
     	self.writeVInt(x)
     	
     	
     self.writeVInt(1) #IntValueEntry
     for x in range(1):
      self.writeInt(1)
      self.writeInt(41000000 + 27)
      
     self.writeVInt(0) #TimedIntValueEntry
     for x in range(0):
     	self.writeVInt(x)
     	
     	
     self.writeVInt(0) #customevent
     for x in range(0):
     	self.writeVInt(x)