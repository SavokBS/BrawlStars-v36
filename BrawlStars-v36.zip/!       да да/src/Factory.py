from C.Login.Login import Login
from C.Home.GetPlayerProfile import GetPlayerProfile
from C.Home.ChangeAvatar import ChangeAvatar
from C.Leaders.GetLeaderboard import GetLeaderboard
from C.Home.KeepAlive import KeepAlive
from C.Battle.AskForBattleEnd import AskForBattleEnd
from C.Home.GoHome import GoHome
from C.Home.EndClientTurn import EndClientTurn
from C.Room.CreateTeam import CreateTeam
from C.Room.LeaveTeam import LeaveTeam
from C.Room.SetReadyTeam import SetReadyTeam
from C.Room.SetLocationTeam import SetLocationTeam

from C.Club.CreateAlliance import CreateAlliance
from C.Club.AskForAllianceData import AskForAllianceData
from C.Home.AvatarNameCheckRequest import AvatarNameCheckRequest
from C.Room.TeamPremadeChat import TeamPremadeChat
from C.Room.TeamSpectate import TeamSpectate
packets = {
    10101: Login,
    10108: KeepAlive,
    10212: ChangeAvatar,
    14102: EndClientTurn,
    14109: GoHome,
    14110: AskForBattleEnd,
    14113: GetPlayerProfile,
    14350: CreateTeam,
    14353: LeaveTeam,
    14355: SetReadyTeam,
    14363: SetLocationTeam,
    14358: TeamSpectate,
    14403: GetLeaderboard,
    14301: CreateAlliance,
    14302: AskForAllianceData,
    14600: AvatarNameCheckRequest,
    14369: TeamPremadeChat,
}